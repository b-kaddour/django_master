
if __name__ == '__main__':
    help('modules')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/

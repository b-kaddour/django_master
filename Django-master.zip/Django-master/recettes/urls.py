from django.urls import path
from . import views

urlpatterns = [
    #path('', views.index, name='index')
    #path('', views.listing, name='listing'),
    #path('', views.recette, name='details'),
    #path('recherche', views.recette_search, name='recette_search'),
]
